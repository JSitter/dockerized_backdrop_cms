<?php
/**
 * @file
 * Configuration file for the Backdrop CMS multi-site feature.
 *
 * This file allows you to map hostnames, ports, and pathnames to configuration
 * directories. Information on how to set up multisites see the README.md file
 * in this directory.
 */
// $sites['example.com'] = 'example';
